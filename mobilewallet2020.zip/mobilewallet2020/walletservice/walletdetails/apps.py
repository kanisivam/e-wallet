from django.apps import AppConfig


class WalletdetailsConfig(AppConfig):
    name = 'walletdetails'
