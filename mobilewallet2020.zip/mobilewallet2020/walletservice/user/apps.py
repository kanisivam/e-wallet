from django.apps import AppConfig


class CuserConfig(AppConfig):
    name = 'cuser'
